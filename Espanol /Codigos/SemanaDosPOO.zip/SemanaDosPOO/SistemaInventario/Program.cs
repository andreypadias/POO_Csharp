﻿// See https://aka.ms/new-console-template for more information
using SistemaInventario;

Inventario inventarioTiendaUno = new Inventario();

//Menu
bool continuar = true;

do
{
    try
    {
        Console.WriteLine("*****Seleccione una opcion:***");
        Console.WriteLine("1 - Agregar Producto");
        Console.WriteLine("2 - Editar Producto");
        Console.WriteLine("3 - Mostrar Productos");
        Console.WriteLine("4 - Eliminar Producto");
        Console.WriteLine("5 - Salir");

        string opcion = Console.ReadLine();

        switch (opcion)
        {
            case "1":
                Console.WriteLine("Agregando Producto");
                Console.WriteLine("Ingrese el precio del producto:");
                decimal precioProducto = decimal.Parse(Console.ReadLine());
                break;
            case "2":
                Console.WriteLine("Editando Producto");
                break;
            case "3":
                Console.WriteLine("Mostrando Productos");
                break;
            case "4":
                Console.WriteLine("Eliminando Producto");
                break;
            case "5":
                Console.WriteLine("******Saliendo del sistema******");
                continuar = false;
                break;
            default:
                Console.WriteLine("Seleccionar una opcion entre 1 y 5");
                break;
        }
    }
    catch (Exception e)
    {
        Console.WriteLine($"Ha ocurrido un error. Error {e.Message}");
    }
    

} while (continuar);

