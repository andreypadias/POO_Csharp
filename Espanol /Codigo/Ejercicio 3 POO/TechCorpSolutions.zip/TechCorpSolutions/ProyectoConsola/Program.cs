﻿// See https://aka.ms/new-console-template for more information
// Creación de un proyecto
using ProyectoConsola.Clases;

// Variables de proyecto
Proyecto proyecto1;
List<Empleado> empleados = new List<Empleado>();

// Bloque try-catch para captura de posibles errores
try
{
    Console.WriteLine("Ingrese el nombre del proyecto:");
    string nombreProyecto = Console.ReadLine();

    Console.WriteLine("Ingrese la fecha de inicio (yyyy-MM-dd):");
    DateTime fechaInicio = DateTime.Parse(Console.ReadLine());

    Console.WriteLine("Ingrese la fecha de fin (yyyy-MM-dd):");
    DateTime fechaFin = DateTime.Parse(Console.ReadLine());

    Console.WriteLine("Ingrese el estado del proyecto (Activo, En Proceso, Finalizado):");
    string estadoProyecto = Console.ReadLine();

    proyecto1 = new Proyecto(nombreProyecto, fechaInicio, fechaFin, estadoProyecto);

    bool agregarMasEmpleados = true;
    do
    {
        Console.WriteLine("Ingrese el nombre del empleado:");
        string nombreEmpleado = Console.ReadLine();

        Console.WriteLine("Ingrese la posición del empleado (Desarrollador, Tester, etc.):");
        string posicionEmpleado = Console.ReadLine();

        Console.WriteLine("Ingrese las horas trabajadas por el empleado:");
        int horasTrabajadas = int.Parse(Console.ReadLine());

        // Preguntar si es un gerente de proyecto
        Console.WriteLine("¿Es este empleado un Gerente de Proyecto? (Sí/No):");
        string respuesta = Console.ReadLine().ToLower();

        Empleado empleado;
        if (respuesta == "sí" || respuesta == "si")
        {
            Console.WriteLine("Ingrese la cantidad de proyectos gestionados:");
            int cantidadProyectos = int.Parse(Console.ReadLine());
            empleado = new GerenteProyecto(nombreEmpleado, cantidadProyectos);
        }
        else
        {
            empleado = new Empleado(nombreEmpleado, posicionEmpleado);
        }

        empleado.SetHorasTrabajadas(horasTrabajadas);
        empleados.Add(empleado);
        proyecto1.AgregarEmpleado(empleado);

        Console.WriteLine("¿Desea agregar otro empleado? (Sí/No):");
        respuesta = Console.ReadLine().ToLower();
        agregarMasEmpleados = (respuesta == "sí" || respuesta == "si");

    } while (agregarMasEmpleados);

    // Generar y enviar el reporte
    proyecto1.GenerarReporte();
    proyecto1.EnviarReporte();

}
catch (Exception ex)
{
    Console.WriteLine($"Error: {ex.Message}");
}
