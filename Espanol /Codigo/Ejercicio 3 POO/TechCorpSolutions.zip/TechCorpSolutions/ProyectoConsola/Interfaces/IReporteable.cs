﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoConsola.Interfaces
{
    public interface IReporteable
    {
        void GenerarReporte();
        void EnviarReporte();
    }
}
