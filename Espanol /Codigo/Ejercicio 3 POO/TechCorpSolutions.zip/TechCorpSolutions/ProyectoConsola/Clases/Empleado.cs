﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoConsola.Clases
{
    public class Empleado
    {
        private string nombre;
        private string posicion;
        private int horasTrabajadas;

        // Constructor
        public Empleado(string nombre, string posicion)
        {
            this.nombre = nombre;
            this.posicion = posicion;
        }

        // Encapsulación con Getters y Setters
        public string Nombre
        {
            get { return nombre; }
        }

        public string Posicion
        {
            get { return posicion; }
        }

        public int HorasTrabajadas
        {
            get { return horasTrabajadas; }
        }

        // Método para asignar horas trabajadas con manejo de excepciones
        public void SetHorasTrabajadas(int horas)
        {
            try
            {
                if (horas < 0)
                {
                    throw new ArgumentException("Las horas trabajadas no pueden ser negativas.");
                }
                this.horasTrabajadas = horas;
            }
            catch (ArgumentException ex)
            {
                Console.WriteLine($"Error de Asignación: {ex.Message}");
            }
        }
    }
}
