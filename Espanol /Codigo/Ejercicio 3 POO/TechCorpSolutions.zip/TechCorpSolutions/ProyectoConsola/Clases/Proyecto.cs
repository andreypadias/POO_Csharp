﻿using ProyectoConsola.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoConsola.Clases
{
    public class Proyecto : IReporteable
    {
        private string nombreProyecto;
        private DateTime fechaInicio;
        private DateTime fechaFin;
        private string estadoProyecto;
        private List<Empleado> empleadosAsignados;

        // Constructor
        public Proyecto(string nombreProyecto, DateTime fechaInicio, DateTime fechaFin, string estadoProyecto)
        {
            this.nombreProyecto = nombreProyecto;
            this.fechaInicio = fechaInicio;
            this.fechaFin = fechaFin;
            this.estadoProyecto = estadoProyecto;
            this.empleadosAsignados = new List<Empleado>();
        }

        // Método para agregar empleados al proyecto
        public void AgregarEmpleado(Empleado empleado)
        {
            empleadosAsignados.Add(empleado);
        }

        // Método para calcular el total de horas trabajadas
        public int CalcularTotalHorasTrabajadas()
        {
            int totalHoras = 0;
            foreach (Empleado emp in empleadosAsignados)
            {
                totalHoras += emp.HorasTrabajadas;
            }
            return totalHoras;
        }

        public void GenerarReporte()
        {
            Console.WriteLine("---- Reporte del Proyecto ----");
            Console.WriteLine($"Nombre del Proyecto: {nombreProyecto}");
            Console.WriteLine($"Estado del Proyecto: {estadoProyecto}");
            Console.WriteLine("Empleados Asignados:");
            foreach (Empleado emp in empleadosAsignados)
            {
                Console.WriteLine($"- {emp.Nombre} ({emp.Posicion}): {emp.HorasTrabajadas} horas trabajadas.");
            }
            Console.WriteLine($"Total de horas trabajadas: {CalcularTotalHorasTrabajadas()}");
        }

        // Método para enviar el reporte (Interfaz IReporteable)
        public void EnviarReporte()
        {
            Console.WriteLine("Enviando reporte al gerente...");
        }
    }
}
