﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoConsola.Clases
{
    public class GerenteProyecto:Empleado
    {
        public int CantidadProyectos { get; set; }

        // Constructor
        public GerenteProyecto(string nombre, int cantidadProyectos)
            : base(nombre, "Gerente")
        {
            this.CantidadProyectos = cantidadProyectos;
        }

        // Sobreescritura del método para aplicar bonificación en las horas trabajadas
        public void SetHorasTrabajadasConBonificacion(int horas)
        {
            // Bonificación del 10% en las horas trabajadas
            base.SetHorasTrabajadas((int)(horas * 1.1));
        }
    }
}
