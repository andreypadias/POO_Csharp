﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SistemaInventario
{
    public class Accesorio : Producto
    {
        //Atributos
        public int Peso { get; set; }
        public Accesorio(string nombre, decimal precio, string codigo, int peso) : base(nombre, precio, codigo)
        {
            Peso = peso;
        }

        public override void MostrarDetalles()
        {
            Console.WriteLine($"Accesorio: {Nombre} Precio: {Precio} Peso: {Peso}");
        }

        public override void Editar()
        {
            Console.WriteLine("Ingrese el nuevo peso del articulo:");
            Peso = int.Parse(Console.ReadLine());
        }
    }
}
