﻿// See https://aka.ms/new-console-template for more information
using SistemaInventario;

Inventario inventarioTiendaUno = new Inventario();

//Menu
bool continuar = true;

do
{
    try
    {
        Console.WriteLine("*****Seleccione una opcion:***");
        Console.WriteLine("1 - Agregar Producto");
        Console.WriteLine("2 - Editar Producto");
        Console.WriteLine("3 - Mostrar Productos");
        Console.WriteLine("4 - Eliminar Producto");
        Console.WriteLine("5 - Salir");

        string opcion = Console.ReadLine();

        switch (opcion)
        {
            case "1":
                Console.WriteLine("Agregando Producto");
                Console.WriteLine("1 - Agregar Computadora");
                Console.WriteLine("2 - Agregar Telefono");
                Console.WriteLine("3 - Agregar Tablet");
                Console.WriteLine("4 - Agregar Accesorio");
                string opcionProducto = Console.ReadLine();
                Console.WriteLine("Escriba Nombre del producto:");
                string Nombre = Console.ReadLine();
                Console.WriteLine("Escriba precio del producto:");
                decimal Precio = decimal.Parse(Console.ReadLine());
                Console.WriteLine("Escriba codigo del producto:");
                string Codigo = Console.ReadLine();
                switch (opcionProducto)
                {
                    case "1":
                        
                        Console.WriteLine("Escriba Ram del computador:");
                        int RAM = int.Parse(Console.ReadLine());
                        Console.WriteLine("Escriba procesador del computador:");
                        string Procesador = Console.ReadLine();
                        Computadora pc = new Computadora(Nombre, Precio, Codigo, RAM, Procesador);
                        inventarioTiendaUno.AgregarProducto(pc);
                        break;
                    case "2":
                        Console.WriteLine("Escriba camara del telefono:");
                        string camaraTelefono = Console.ReadLine();
                        Telefono telefono = new Telefono(Nombre, Precio, Codigo,camaraTelefono);
                        inventarioTiendaUno.AgregarProducto(telefono);
                        break;
                    case "3":
                        Console.WriteLine("Escriba sistema operativo del tablet:");
                        string sistemaOperativo = Console.ReadLine();
                        Tablet tablet = new Tablet(Nombre, Precio, Codigo, sistemaOperativo);
                        inventarioTiendaUno.AgregarProducto(tablet);
                        break;
                    case "4":
                        Console.WriteLine("Escriba peso del articulo:");
                        int pesoArticulo = int.Parse(Console.ReadLine());
                        Accesorio accesorio = new Accesorio(Nombre, Precio, Codigo, pesoArticulo);
                        inventarioTiendaUno.AgregarProducto(accesorio);
                        break;
                    default:
                        Console.WriteLine("Por favor seleccionar una opcion valida.");
                        break;
                }

                break;
            case "2":
                Console.WriteLine("***Editando Producto*** \n Ingrese Codigo del producto a editar");
                string codigoProducto = Console.ReadLine();
                inventarioTiendaUno.EditarProducto(codigoProducto);
                break;
            case "3":
                Console.WriteLine("***Mostrando Productos***");
                inventarioTiendaUno.MostrarProductos();
                break;
            case "4":
                Console.WriteLine("***Eliminando Producto*** \n Ingrese codigo de producto a eliminar");
                string codProducto = Console.ReadLine();
                inventarioTiendaUno.EliminarProducto(codProducto);
                break;
            case "5":
                Console.WriteLine("******Saliendo del sistema******");
                continuar = false;
                break;
            default:
                Console.WriteLine("Seleccionar una opcion entre 1 y 5");
                break;
        }
    }
    catch (Exception e)
    {
        Console.WriteLine($"Ha ocurrido un error. Error: {e.Message}");
    }
    

} while (continuar);

