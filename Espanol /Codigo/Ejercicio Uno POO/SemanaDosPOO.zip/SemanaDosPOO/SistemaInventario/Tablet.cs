﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SistemaInventario
{
    public class Tablet : Producto
    {
        //Atributo
        public string SistemaOperativo { get; set; }

        public Tablet(string nombre, decimal precio, string codigo, string sistemaOperativo) : base(nombre, precio, codigo)
        {
            SistemaOperativo = sistemaOperativo;
        }

        public override void MostrarDetalles()
        {
            Console.WriteLine($"Tablet: {Nombre} Precio: {Precio} SO: {SistemaOperativo}");
        }

        public override void Editar()
        {
            Console.WriteLine("Ingrese el nuevo valor de Sistema Operativo:");
            SistemaOperativo = Console.ReadLine();
        }
    }
}
