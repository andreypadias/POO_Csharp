﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bridge
{
    public abstract class Cliente
    {
        protected ICuenta Cuenta;

        public Cliente(ICuenta cuenta)
        {
            Cuenta = cuenta;
        }

        public abstract void RealizarOperacion(decimal monto);

        public void MostrarSaldo() 
        {
            Console.WriteLine($"Saldo Actual: {Cuenta.ObtenerSaldo()}");
        }
    }
}
