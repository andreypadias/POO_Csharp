﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bridge
{
    public class ClienteCorporativo:Cliente
    {
        public ClienteCorporativo(ICuenta cuenta) : base(cuenta) { }

        public override void RealizarOperacion(decimal monto)
        {

            Console.WriteLine("Cliente Corporativo esta realizando un retiro.");
            Cuenta.Retirar(monto);
        }
    }
}
