﻿// See https://aka.ms/new-console-template for more information


using Bridge;

ICuenta cuentaCorriente = new CuentaCorriente();

Cliente clientePersonal = new ClientePersonal(cuentaCorriente);

clientePersonal.RealizarOperacion(1000);
clientePersonal.MostrarSaldo();

Console.WriteLine("-----------");

ICuenta cuentaAhorros = new CuentaAhorros();

Cliente clientePersonal2 = new ClientePersonal(cuentaAhorros);

clientePersonal2.RealizarOperacion(1500);
clientePersonal2.MostrarSaldo();

Console.WriteLine("-------------");

ICuenta cuentaAhorrosDos = new CuentaAhorros();
Cliente clienteCorporativo = new ClienteCorporativo(cuentaAhorrosDos);

clienteCorporativo.RealizarOperacion(900);
clienteCorporativo.MostrarSaldo();

