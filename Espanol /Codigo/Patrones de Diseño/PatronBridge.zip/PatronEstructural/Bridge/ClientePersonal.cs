﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bridge
{
    public class ClientePersonal : Cliente
    {
        public ClientePersonal(ICuenta cuenta):base(cuenta) { }
        
        public override void RealizarOperacion(decimal monto)
        {

            Console.WriteLine("Cliente Personal esta realizando un deposito.");
            Cuenta.Depositar(monto);
        }
    }
}
