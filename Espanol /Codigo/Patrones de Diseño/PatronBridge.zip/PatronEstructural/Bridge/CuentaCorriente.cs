﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bridge
{
    public class CuentaCorriente : ICuenta
    {
        private decimal Saldo; //Monto disponible

        public void Depositar(decimal monto)
        {
            Saldo += monto;
            Console.WriteLine($"Deposito de {monto} realizado exitosamente" +
                $" en la Cuenta Corriente.");
        }

        public decimal ObtenerSaldo() => Saldo;

        public void Retirar(decimal monto)
        {
            if (Saldo >= monto)
            {
                Saldo -= monto;
                Console.WriteLine($"Retiro de {monto} realizado de la cuenta corriente.");

            }
            else 
            {
                Console.WriteLine("Saldo Insuficiente.");
            }
        }
    }
}
