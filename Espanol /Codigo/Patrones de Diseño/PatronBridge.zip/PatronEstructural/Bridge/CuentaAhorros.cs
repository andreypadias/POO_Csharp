﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bridge
{
    public class CuentaAhorros:ICuenta
    {
        private decimal Saldo; //Monto disponible

        public void Depositar(decimal monto)
        {
            Saldo += monto;
            Console.WriteLine($"Deposito de {monto} realizado exitosamente" +
                $" en la Cuenta Ahorros.");
        }

        public decimal ObtenerSaldo() => Saldo;

        public void Retirar(decimal monto)
        {
            if (Saldo >= monto)
            {
                Saldo -= monto;
                Console.WriteLine($"Retiro de {monto} realizado de la cuenta Ahorros.");

            }
            else
            {
                Console.WriteLine("Saldo Insuficiente.");
            }
        }
    }
}
