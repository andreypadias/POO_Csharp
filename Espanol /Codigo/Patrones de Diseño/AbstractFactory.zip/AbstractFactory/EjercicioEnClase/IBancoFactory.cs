﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjercicioEnClase
{
    //Interfaz de la Abstract Factory
    public interface IBancoFactory
    {
        
        ICuentaBancaria CrearCuenta();
        ITarjeta CrearTarjeta();
        
    }
}
