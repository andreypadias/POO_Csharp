﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjercicioEnClase
{
    public class TarjetaNacional : ITarjeta
    {
        public void MostrarDetallesTarjeta()
        {
            Console.WriteLine("Tarjeta Nacional \n 40202920292092029 \n 789 \n 10-27");
        }
    }
}
