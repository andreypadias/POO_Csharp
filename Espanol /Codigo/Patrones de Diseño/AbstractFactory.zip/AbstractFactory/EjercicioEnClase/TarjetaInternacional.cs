﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjercicioEnClase
{
    public class TarjetaInternacional:ITarjeta
    {
        public void MostrarDetallesTarjeta()
        {
            Console.WriteLine("Tarjeta Internacional \n 30202962525265162 \n 123 \n 12-26");
        }
    }
}
