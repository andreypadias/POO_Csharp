﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjercicioEnClase
{
    public class CuentaBancariaInternacional : ICuentaBancaria
    {
        public void MostrarDetallesCuenta()
        {
            Console.WriteLine("Cuenta Bancaria Internacional. Solo valida en el extranjero.");
        }
    }
}
