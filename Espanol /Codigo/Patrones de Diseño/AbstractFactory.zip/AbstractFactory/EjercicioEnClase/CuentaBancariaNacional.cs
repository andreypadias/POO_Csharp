﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjercicioEnClase
{
    public class CuentaBancariaNacional : ICuentaBancaria
    {
        public void MostrarDetallesCuenta()
        {
            Console.WriteLine("Cuenta Bancaria Nacional. Valida solo en mercado local.");
        }
    }
}
