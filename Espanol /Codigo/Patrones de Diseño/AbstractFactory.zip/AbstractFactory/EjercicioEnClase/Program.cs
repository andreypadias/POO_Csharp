﻿// See https://aka.ms/new-console-template for more information

using EjercicioEnClase;

Cliente clienteNacional = new Cliente(new BancoNacionalConcreteFactory());
clienteNacional.MostrarProductosCliente();

Cliente clienteInternacional = new Cliente(new BancoInternacionConcreteFactory());
clienteInternacional.MostrarProductosCliente();
