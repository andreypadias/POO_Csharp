﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjercicioEnClase
{
    public class Cliente
    {
        private readonly ICuentaBancaria CuentaBancaria;
        private readonly ITarjeta Tarjeta;

        public Cliente(IBancoFactory bancoFactory) 
        {
            CuentaBancaria = bancoFactory.CrearCuenta();
            Tarjeta = bancoFactory.CrearTarjeta();
        }

        public void MostrarProductosCliente() 
        {
            CuentaBancaria.MostrarDetallesCuenta();
            Tarjeta.MostrarDetallesTarjeta();
        }
    }
}
