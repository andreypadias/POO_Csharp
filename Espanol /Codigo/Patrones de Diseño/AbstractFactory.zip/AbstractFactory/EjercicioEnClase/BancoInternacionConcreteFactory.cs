﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjercicioEnClase
{
    public class BancoInternacionConcreteFactory:IBancoFactory
    {

        public ICuentaBancaria CrearCuenta() => new CuentaBancariaInternacional();

        public ITarjeta CrearTarjeta() => new TarjetaInternacional();
    }
}
