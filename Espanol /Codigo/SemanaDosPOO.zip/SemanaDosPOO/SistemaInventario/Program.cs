﻿// See https://aka.ms/new-console-template for more information
using SistemaInventario;



Computadora compu = new Computadora("Computadora Lenovo", 250000, "cod78555", 16, "Core i9");

compu.MostrarDetalles();

Telefono tel1 = new Telefono("Samsung Galaxy 9", 500000, "cod54555","Camara 85 MP");

tel1.MostrarDetalles();